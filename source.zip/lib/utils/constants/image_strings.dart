import 'package:flutter/material.dart';

class TImages {


  static const String google = "assets/images/google.png";
  static const String facebook = "assets/images/facebook.png";
  static const String darkAppLogo = "assets/logos/logo.png";
  static const String lightAppLogo = "assets/logos/logo.png";
  static const String image = "assets/images/image.png";
  static const String image2 = "assets/images/gif_demo.gif";
}
