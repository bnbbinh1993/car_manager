

class APIConstants {
  static const String tSecretAPIKey = "cwt_live_abcyzdsa";
}